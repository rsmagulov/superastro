// KB: row selection helper
window.kbSelectRow = function (rowEl) {
  if (!rowEl) return;

  const table = rowEl.closest("table");
  if (table) {
    table.querySelectorAll("tr.kb-row.is-selected").forEach((tr) => tr.classList.remove("is-selected"));
  }
  rowEl.classList.add("is-selected");
};
